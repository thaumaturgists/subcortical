\version "2.24.2"

\header {
  title = "Thank You for Loving Me"
  subtitle = "Erratic Cinematic Arrangement"
  composer = "Feather Heart / Patrick"
  tagline = "For orchestra, choir, and light"
}

global = {
  \key c \major
  \time 4/4
  \tempo "Unpredictable" 4 = 120
}

%-------------------------------------------------
% Core themes with erratic changes
%-------------------------------------------------

melodyLead = \relative c' {
  \global

  % Intro with unexpected rests and accents
  c8-. e-. g-. c | a4( c8-. e a) | f4( a8-. c a) | g8-. b-. d g |

  % Verse with sudden dynamic changes
  e4 d c b\> | a8-. g-. e c\! | f4 f8-. f16 e | g2 a4( g e) |

  % Chorus with syncopation
  a8-. g-. e c | b2\> a8-. g e\! | c'8\pp b a4. g8 | a4. g8 e c\mf |
  a16 b a8 g4 f16 e | b4\> a8-. g e\! | c'8-. b a4. g8 | c2\ff\fermata
}

% A more varied countermelody
counterMelody = \relative c'' {
  \global
  r8 c16( d e4) | e8 r8 e4( d)\< |
  c2( b4 a) | g8\> r8 a4 c\! |
  e8-. d16\pp( c) | b8 r16 b( c e) |
  d8( c4) b8 r8 | a2 r2 |

  % Chorus lift with syncopation
  e'16( d c8) | b16( c e4) |
  d8( c4 b8) | a16( g e4) |
  f8( e4 d8) | c16( d f4) |
  e8( d4 c) | c2
}

% Irregular string harmony
stringHarmony = \relative c' {
  \global
  % Intro
  c8-. c-. c4 ~ | c8-. c-. c4 | f8 f4. c8 ~ | f8-. f-. f4 |

  % Verse
  c8( c4) | c8( c4) | f8. e16( e4) | g2( f4) |

  % Chorus
  f8 f4 | g8 g4. | c2 a8-. | f4( g2) |

  f8( g) | g2 c8-. | c16 d c4 | c1
}

% Brass with sudden dynamic changes
brassSwells = \relative c' {
  \global
  % Intro – subtle to strong
  c1\pp\> | a1\! | f\mf\< | g1\! |

  % Verse – supportive but surprising
  c2\> b\! c d | a2\mf a\> g\! | f1\p\> | g1\! |

  % Chorus – bold and syncopated
  f1\ff | g2\> c\! | c4\< e g c | a1\pp | 
  f1 | g2\> \< c!\mp | c2 b\> c | c1
}

% Updated choir chords for unpredictability
choirChords = \relative c' {
  \global
  % Intro with dynamic shifts
  c1\pp | a4 s4 s2 | f1 | g2\>

  % Verse - unexpected rests
  c1 s2 | a | f s4 s4 | g1

  % Chorus – dynamic exploration
  f1\p | g1\> | c\mf ~ | a1\pp | 
  f1 | g1\> | c1\mp ~ | c1
}

% Bass line with unexpected variations
bassLine = \relative c {
  \global
  % Intro with off-beat emphasis
  c8-. a-. a1 | f8-. g-. g1 |

  % Verse pattern
  c8 c\> | a4\! a a | f8 f\> | g4 g\! |

  % Chorus pattern
  f1| g2 g8-. g-. | c8 c4 a | f8-. g-. g1 |
  c8 c b c4 | c1
}

% More varied harp arpeggios
harpArp = \relative c' {
  \global
  % Intro
  <c e g c>16( g e c) | <a c e a>16( e c a) | <f a c f>16( c a f) | <g b d g>16( d b g) |

  % Verse with off-beats
  <c e g c>16( g e c) | <a c e a>16( e c a) | <f a c f>16( c a f) | <g b d g>16( d b g) |

  % Chorus with added motion
  <f a c f>16( c a f) | <g b d g>16( d b g) | <c e g c>16( g e c) | <a c e a>16( e c a) |
  <f a c f>16( c a f) | <g b d g>16( d b g) | <c e g c>16( g e c) | <c e g c>2 r2
}

% Percussion with erratic patterns
percPattern = {
  \global
  % Intro
  s2. | c16 c c c4 c | c16 c c c4 c |

  % Verse
  c4 c8 c | c16 c c c4 | s1 | c4-. c16 c c |

  % Chorus
  c16 c4 c | c16 c4 c | c16 c4 c | s1 |
  c16 c4 c | c16 c c4 | c16 c4 c | s1
}

%-------------------------------------------------
% Lyrics (Same as before)
%-------------------------------------------------
mainLyrics = \lyricmode {
  I would sing my love on the roof -- tops,
  turn -- ing stars in -- to dia -- monds, just for one.
  My truth, the songs of songs come from it,
  from my light that lets life go on and on.
  Thank you for pull -- ing me down off that wall,
  thank you for lov -- ing me through it all.
  Look -- ing in -- to the world, in -- to the im -- pos -- si -- ble,
  we find our most cheer -- ful joy.
}

%-------------------------------------------------
% Score structure (Same as before)
%-------------------------------------------------

\score {
  <<
    %-------------------------
    % Chords
    %-------------------------
    \new ChordNames { \harmony }

    %-------------------------
    % Woodwinds
    %-------------------------
    \new StaffGroup <<
      \new Staff = "FluteI" {
        \set Staff.instrumentName = #"Flute I"
        \clef treble
        \counterMelody
      }
      \new Staff = "FluteII" {
        \set Staff.instrumentName = #"Flute II"
        \clef treble
        \counterMelody
      }
      \new Staff = "OboeI" {
        \set Staff.instrumentName = #"Oboe I"
        \clef treble
        \melodyLead
      }
      \new Staff = "ClarinetI" {
        \set Staff.instrumentName = #"Clarinet in Bb"
        \clef treble
        \melodyLead
      }
    >>

    %-------------------------
    % Brass
    %-------------------------
    \new StaffGroup <<
      \new Staff = "HornI" {
        \set Staff.instrumentName = #"Horn in F I"
        \clef treble
        \brassSwells
      }
      \new Staff = "TrumpetI" {
        \set Staff.instrumentName = #"Trumpet in Bb"
        \clef treble
        \brassSwells
      }
      \new Staff = "TromboneI" {
        \set Staff.instrumentName = #"Trombone"
        \clef bass
        \bassLine
      }
    >>

    %-------------------------
    % Strings
    %-------------------------
    \new StaffGroup <<
      \new Staff = "VlnI" {
        \set Staff.instrumentName = #"Violins I"
        \clef treble
        \melodyLead
      }
      \new Staff = "VlnII" {
        \set Staff.instrumentName = #"Violins II"
        \clef treble
        \counterMelody
      }
      \new Staff = "Viola" {
        \set Staff.instrumentName = #"Violas"
        \clef alto
        \stringHarmony
      }
      \new Staff = "Cello" {
        \set Staff.instrumentName = #"Cellos"
        \clef bass
        \stringHarmony
      }
      \new Staff = "Bass" {
        \set Staff.instrumentName = #"Basses"
        \clef bass
        \bassLine
      }
    >>

    %-------------------------
    % Harp & Piano
    %-------------------------
    \new StaffGroup <<
      \new Staff = "Harp" {
        \set Staff.instrumentName = #"Harp"
        \clef treble
        \harpArp
      }
      \new PianoStaff <<
        \set PianoStaff.instrumentName = #"Piano"
        \new Staff = "PianoRH" {
          \clef treble
          \stringHarmony
        }
        \new Staff = "PianoLH" {
          \clef bass
          \bassLine
        }
      >>
    >>

    %-------------------------
    % Choir
    %-------------------------
    \new ChoirStaff <<
      \new Staff = "Soprano" {
        \set Staff.instrumentName = #"Soprano"
        \clef treble
        \melodyLead
      }
      \new Lyrics \lyricsto "Soprano" { \mainLyrics }
      \new Staff = "Alto" {
        \set Staff.instrumentName = #"Alto"
        \clef treble
        \choirChords
      }
      \new Staff = "Tenor" {
        \set Staff.instrumentName = #"Tenor"
        \clef treble
        \choirChords
      }
      \new Staff = "BassChoir" {
        \set Staff.instrumentName = #"Bass"
        \clef bass
        \bassLine
      }
    >>

    %-------------------------
    % Percussion (erratic)
    %-------------------------
    \new StaffGroup <<
      \new DrumStaff = "Timpani" {
        \set Staff.instrumentName = #"Timpani"
        \percPattern
      }
      \new DrumStaff = "Cymbals" {
        \set Staff.instrumentName = #"Cymbals & Chimes"
        \percPattern
      }
      \new DrumStaff = "Taiko" {
        \set Staff.instrumentName = #"Taiko / Bass Drum"
        \percPattern
      }
    >>
  >>

  \layout { }
  \midi { }
}
