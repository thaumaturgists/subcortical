\version "2.24.2"
\header { 
  title = "Thank You for Loving Me (lead sheet)"
  composer = "Feather Heart / Patrick" 
}

global = { \key c \major \time 4/4 \tempo 4 = 96 }

melody = \relative c' {
  \global
  % Intro (4 bars)
  c4 e g c | a4 c e a | f4 a c a | g4 b d g |
  % Verse 1 (first 4 bars)
  e4 d c b | a g e c | f e d c | g a g e |
  % Chorus (first 4 bars)
  a4 g e c | b a g e | c'4 b a g | a g e c |
  % Chorus (finish)
  a4 g f e | b a g e | c'4 b a g | c2 \bar "|."
}

harmony = \chordmode {
  \global
  c1 | a:m1 | f1 | g1 |
  c1 | a:m1 | f1 | g1 |
  f1 | g1 | c1 | a:m1 |
  f1 | g1 | c1 | c1
}

myLyrics = \lyricmode {
  I would sing my love on the roof-tops, turning stars in-to dia-monds, just for one.
  My truth, the songs of songs come from it, from my light that lets life go on and on.
  Thank you for pull-ing me down off that wall, thank you for lov-ing me through it all.
  Look-ing in-to the world, in-to the im-pos-si-ble, we find our most cheer-ful joy.
}

\score {
  <<
    \new ChordNames \harmony
    \new Staff {
      \clef treble
      \melody
      \addlyrics { \myLyrics }
    }
  >>
  \layout { }
}
