\version "2.24.2"

\header {
  title = "Thank You for Loving Me"
  subtitle = "Lead Sheet"
  poet = "Lyrics & Music by Feather Heart (Patrick)"
  tagline = "A song of gratitude, light, and rescue"
}

global = {
  \key c \major
  \time 4/4
  \tempo "Warm, steady" 4 = 96
}

melody = \relative c' {
  \global

  % Intro
  \mark \markup \bold "Intro"
  c4( e g c) | a4( c e a) | f4( a c a) | g4( b d g) |

  % Verse 1
  \mark \markup \bold "Verse"
  e4 d c b | a g e c | f e d c | g a g e |

  % Chorus
  \mark \markup \bold "Chorus"
  a4 g e c | b a g e | c'4 b a g | a g e c |
  a4 g f e | b a g e | c'4 b a g | c2 \bar "|."
}

harmony = \chordmode {
  \global
  c1 | a:m | f | g |
  c | a:m | f | g |
  f | g | c | a:m |
  f | g | c | c
}

myLyrics = \lyricmode {
  I would sing my love on the roof -- tops,
  turn -- ing stars in -- to dia -- monds, just for one.
  My truth, the songs of songs come from it,
  from my light that lets life go on and on.
  Thank you for pull -- ing me down off that wall,
  thank you for lov -- ing me through it all.
  Look -- ing in -- to the world, in -- to the im -- pos -- si -- ble,
  we find our most cheer -- ful joy.
}

\paper {
  #(set-paper-size "letter")
  top-margin = 15\mm
  bottom-margin = 15\mm
}

\layout {
  \context {
    \ChordNames
    chordChanges = ##t
    \override ChordName.font-size = #1
  }
  \context {
    \Lyrics
    \override LyricText.font-size = #0.5
  }
}

\score {
  <<
    \new ChordNames \harmony
    \new Staff {
      \clef treble
      \melody
    }
    \addlyrics { \myLyrics }
  >>
  \midi { }
}