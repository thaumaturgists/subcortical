\version "2.24.2"

\header {
  title = "Thank You for Loving Me"
  subtitle = "Cinematic Orchestral Arrangement"
  composer = "Feather Heart / Patrick"
  tagline = "For orchestra, choir, and light"
}

global = {
  \key c \major
  \time 4/4
  \tempo "Warm, luminous" 4 = 96
}

%-------------------------------------------------
% Core themes
%-------------------------------------------------

melodyLead = \relative c' {
  \global

  % Intro (strings & winds will echo this)
  c4( e g c) | a4( c e a) | f4( a c a) | g4( b d g) |

  % Verse
  e4 d c b | a g e c | f e d c | g a g e |

  % Chorus
  a4 g e c | b a g e | c'4 b a g | a g e c |
  a4 g f e | b a g e | c'4 b a g | c2 \bar "|."
}

% A gentle countermelody for high winds and violins
counterMelody = \relative c'' {
  \global
  r2 c4( d) | e2 ~ e4( d) |
  c2( b4 a) | g2( a4 c) |
  e2( d4 c) | b2( c4 e) |
  d2( c4 b) | a2 r2 |

  % Chorus lift
  e'2 d4( c) | b2( c4 e) |
  d2( c4 b) | a2( g4 e) |
  f2( e4 d) | c2( d4 f) |
  e2( d4 c) | c2
}

% String pad / harmonic bed
stringHarmony = \relative c' {
  \global
  % Intro
  c1 ~ | c | f ~ | f |
  % Verse
  c1 ~ | c | f ~ | g |
  % Chorus
  f1 ~ | g | c ~ | a |
  f1 ~ | g | c ~ | c
}

% Brass swells (soft to strong)
brassSwells = \relative c' {
  \global
  % Intro – subtle
  c1\pp\< | a\! | f\< | g\! |
  % Verse – supportive
  c1\< | a\! | f\< | g\! |
  % Chorus – opening up
  f1\mf\< | g\! | c\ff | a\> |
  f1\mf | g\> | c1\mp ~ | c
}

% Choir chords (ahh)
choirChords = \relative c' {
  \global
  % Intro – distant
  c1\pp | a | f | g |
  % Verse – under the surface
  c1 | a | f | g |
  % Chorus – opening, grateful
  f1\mp | g | c\mf | a\mp |
  f1 | g | c\pp ~ | c
}

% Simple bass foundation
bassLine = \relative c {
  \global
  c1 | a | f | g |
  c1 | a | f | g |
  f1 | g | c | a |
  f1 | g | c | c
}

% Harp arpeggios based on harmony
harpArp = \relative c' {
  \global
  % Intro
  <c e g c>8( g e c  g' e c g) |
  <a c e a>8( e c a  e' c a e) |
  <f a c f>8( c a f  c' a f c) |
  <g b d g>8( d b g  d' b g d) |

  % Verse
  <c e g c>8( g e c  g' e c g) |
  <a c e a>8( e c a  e' c a e) |
  <f a c f>8( c a f  c' a f c) |
  <g b d g>8( d b g  d' b g d) |

  % Chorus
  <f a c f>8( c a f  c' a f c) |
  <g b d g>8( d b g  d' b g d) |
  <c e g c>8( g e c  g' e c g) |
  <a c e a>8( e c a  e' c a e) |

  <f a c f>8( c a f  c' a f c) |
  <g b d g>8( d b g  d' b g d) |
  <c e g c>8( g e c  g' e c g) |
  <c e g c>2 r2
}

% Light percussion groove
percPattern = {
  \global
  % Use simple rhythmic pattern; instruments differ by staff
  % Intro
  s1*2
  s2 c4 c | c4 c c c |
  % Verse
  c4 c c c | c4 c c c | s1 | c4 c c c |
  % Chorus
  c4 c c c | c4 c c c | c4 c c c | s1 |
  c4 c c c | c4 c c c | c4 c c c | s1
}

%-------------------------------------------------
% Lyrics for main vocal line
%-------------------------------------------------
mainLyrics = \lyricmode {
  I would sing my love on the roof -- tops,
  turn -- ing stars in -- to dia -- monds, just for one.
  My truth, the songs of songs come from it,
  from my light that lets life go on and on.
  Thank you for pull -- ing me down off that wall,
  thank you for lov -- ing me through it all.
  Look -- ing in -- to the world, in -- to the im -- pos -- si -- ble,
  we find our most cheer -- ful joy.
}

%-------------------------------------------------
% Layout tweaks
%-------------------------------------------------
\paper {
  #(set-paper-size "letter")
  top-margin = 10\mm
  bottom-margin = 12\mm
  left-margin = 12\mm
  right-margin = 12\mm
}

\layout {
  \context {
    \Score
    \override BarNumber.break-visibility = #'#(#t #t #t)
  }
  \context {
    \ChordNames
    chordChanges = ##t
  }
  \context {
    \Lyrics
    \override LyricText.font-size = #0.5
  }
}

%-------------------------------------------------
% Chords (from your original harmony)
%-------------------------------------------------

harmony = \chordmode {
  \global
  c1 | a:m | f | g |
  c | a:m | f | g |
  f | g | c | a:m |
  f | g | c | c
}

%-------------------------------------------------
% Score structure
%-------------------------------------------------

\score {
  <<
    %-------------------------
    % Chords
    %-------------------------
    \new ChordNames { \harmony }

    %-------------------------
    % Woodwinds
    %-------------------------
    \new StaffGroup <<
      \new Staff = "FluteI" {
        \set Staff.instrumentName = #"Flute I"
        \clef treble
        \counterMelody
      }
      \new Staff = "FluteII" {
        \set Staff.instrumentName = #"Flute II"
        \clef treble
        \counterMelody
      }
      \new Staff = "OboeI" {
        \set Staff.instrumentName = #"Oboe I"
        \clef treble
        \melodyLead
      }
      \new Staff = "ClarinetI" {
        \set Staff.instrumentName = #"Clarinet in Bb"
        \clef treble
        \melodyLead
      }
    >>

    %-------------------------
    % Brass
    %-------------------------
    \new StaffGroup <<
      \new Staff = "HornI" {
        \set Staff.instrumentName = #"Horn in F I"
        \clef treble
        \brassSwells
      }
      \new Staff = "TrumpetI" {
        \set Staff.instrumentName = #"Trumpet in Bb"
        \clef treble
        \brassSwells
      }
      \new Staff = "TromboneI" {
        \set Staff.instrumentName = #"Trombone"
        \clef bass
        \bassLine
      }
    >>

    %-------------------------
    % Strings
    %-------------------------
    \new StaffGroup <<
      \new Staff = "VlnI" {
        \set Staff.instrumentName = #"Violins I"
        \clef treble
        \melodyLead
      }
      \new Staff = "VlnII" {
        \set Staff.instrumentName = #"Violins II"
        \clef treble
        \counterMelody
      }
      \new Staff = "Viola" {
        \set Staff.instrumentName = #"Violas"
        \clef alto
        \stringHarmony
      }
      \new Staff = "Cello" {
        \set Staff.instrumentName = #"Cellos"
        \clef bass
        \stringHarmony
      }
      \new Staff = "Bass" {
        \set Staff.instrumentName = #"Basses"
        \clef bass
        \bassLine
      }
    >>

    %-------------------------
    % Harp & Piano
    %-------------------------
    \new StaffGroup <<
      \new Staff = "Harp" {
        \set Staff.instrumentName = #"Harp"
        \clef treble
        \harpArp
      }
      \new PianoStaff <<
        \set PianoStaff.instrumentName = #"Piano"
        \new Staff = "PianoRH" {
          \clef treble
          \stringHarmony
        }
        \new Staff = "PianoLH" {
          \clef bass
          \bassLine
        }
      >>
    >>

    %-------------------------
    % Choir
    %-------------------------
    \new ChoirStaff <<
      \new Staff = "Soprano" {
        \set Staff.instrumentName = #"Soprano"
        \clef treble
        \melodyLead
      }
      \new Lyrics \lyricsto "Soprano" { \mainLyrics }
      \new Staff = "Alto" {
        \set Staff.instrumentName = #"Alto"
        \clef treble
        \choirChords
      }
      \new Staff = "Tenor" {
        \set Staff.instrumentName = #"Tenor"
        \clef treble
        \choirChords
      }
      \new Staff = "BassChoir" {
        \set Staff.instrumentName = #"Bass"
        \clef bass
        \bassLine
      }
    >>

    %-------------------------
    % Percussion (simplified)
    %-------------------------
    \new StaffGroup <<
      \new DrumStaff = "Timpani" {
        \set Staff.instrumentName = #"Timpani"
        \percPattern
      }
      \new DrumStaff = "Cymbals" {
        \set Staff.instrumentName = #"Cymbals & Chimes"
        \percPattern
      }
      \new DrumStaff = "Taiko" {
        \set Staff.instrumentName = #"Taiko / Bass Drum"
        \percPattern
      }
    >>
  >>

  \layout { }
  \midi { }
}